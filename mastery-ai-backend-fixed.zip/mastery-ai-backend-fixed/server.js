import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 10000;
const MOLLIE_API = 'https://api.mollie.com/v2/payments';

app.get('/', (_req, res) => res.json({ ok: true, service: 'Mastery AI payment backend' }));

app.post('/api/create-payment', async (req, res) => {
  const apiKey = process.env.MOLLIE_API_KEY;
  const siteUrl = process.env.SITE_URL;
  const backendUrl = process.env.BACKEND_URL;
  if (!apiKey || !siteUrl || !backendUrl) return res.status(500).json({ error: 'Server configuration missing' });

  try {
    const response = await fetch(MOLLIE_API, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: { currency: 'EUR', value: '10.00' },
        description: 'Mastery AI — Formation complète',
        redirectUrl: `${siteUrl}/?payment=return`,
        webhookUrl: `${backendUrl}/api/webhook`,
        metadata: { product: 'mastery-ai', version: '1' },
      }),
    });

    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.detail || 'Mollie payment creation failed' });
    return res.json({ checkoutUrl: data._links?.checkout?.href, paymentId: data.id });
  } catch (error) {
    return res.status(500).json({ error: 'Unable to create payment' });
  }
});

app.post('/api/webhook', async (req, res) => {
  const paymentId = req.body?.id;
  if (!paymentId) return res.status(400).send('Missing payment id');
  const apiKey = process.env.MOLLIE_API_KEY;
  if (!apiKey) return res.status(500).send('Server configuration missing');

  try {
    const response = await fetch(`${MOLLIE_API}/${encodeURIComponent(paymentId)}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    const payment = await response.json();
    if (!response.ok) return res.status(response.status).send('Mollie verification failed');

    if (payment.status === 'paid') {
      console.log('PAID', payment.id, payment.amount?.value, payment.metadata);
      // Secure access/account storage will be connected here next.
    }
    return res.status(200).send('OK');
  } catch {
    return res.status(500).send('Webhook error');
  }
});

app.listen(PORT, () => console.log(`Mastery AI backend listening on ${PORT}`));
