# Mastery AI — Mollie backend

Render Web Service backend for the Mastery AI €10 Mollie checkout.

Environment variables:
- MOLLIE_API_KEY = your Mollie Live API key (secret; never put in GitHub)
- SITE_URL = your GitHub Pages URL, e.g. https://YOUR-USER.github.io/mastery-ai/
- BACKEND_URL = your Render service URL, e.g. https://mastery-ai-payment.onrender.com

Build command: npm install
Start command: npm start

Endpoints:
- POST /api/create-payment
- POST /api/webhook

The webhook verifies the payment directly with Mollie. Database/account-based access control is the next step for secure automatic unlocking.
